<?php
include("cls_footer.php");
$obj_adm=new Registro;
$titulo="Administrar Footer";
include("cls_MantixDirector1.php");
?>