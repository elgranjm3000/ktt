<?php
	error_reporting(0);
	include("cls_imagenes_producto.php");
	$obj_adm=new Imagenes_Producto();
	$titulo="Administrar Im&aacute;genes de Productos";
	include("cls_MantixDirector1.php");
?>