<?php
	error_reporting(0);
	include("cls_productos.php");
	$obj_adm=new Productos();
	$titulo="Administrar Productos";
	include("cls_MantixDirector1.php");
?>