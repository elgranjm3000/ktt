<?php
	error_reporting(0);
	include("cls_categorias_productos.php");
	$obj_adm=new Categorias_productos();
	$titulo="Administrar Categor&iacute;as de Productos";
	include("cls_MantixDirector1.php");
?>