<?php
	error_reporting(0);
	include("cls_preguntas_frecuentes.php");
	$obj_adm=new Preguntas_frecuentes();
	$titulo="Administrar Preguntas Frecuentes";
	include("cls_MantixDirector1.php");
?>