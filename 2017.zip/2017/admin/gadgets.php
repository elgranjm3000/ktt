<?php
	error_reporting(0);
	include("cls_gadgets.php");
	$obj_adm=new Gadgets();
	$titulo="Administrar Gadgets";
	include("cls_MantixDirector1.php");
?>