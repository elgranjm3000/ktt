<?php
error_reporting(0);
include("cls_varios.php");
$obj_adm=new Varios();
$titulo="Administrar Recursos Varios";
include("cls_MantixDirector1.php");
?>