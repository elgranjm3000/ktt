<?php
	error_reporting(0);
	include("cls_inicio.php");
	$obj_adm=new Inicio;
	$titulo="Administrar Secci&oacute;n Inicio";
	include("cls_MantixDirector1.php");
?>