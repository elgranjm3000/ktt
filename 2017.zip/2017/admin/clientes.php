<?php
	error_reporting(0);
	include("cls_clientes.php");
	$obj_adm=new Clientes();
	$titulo="Administrar Clientes";
	include("cls_MantixDirector1.php");
?>