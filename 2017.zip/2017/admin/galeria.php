<?php
	error_reporting(0);
	include("cls_galeria.php");
	$obj_adm=new Galeria_fotos();
	$titulo="Administrar Galer&iacute;a";
	include("cls_MantixDirector1.php");
?>