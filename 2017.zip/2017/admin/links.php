<?php
error_reporting(0);
include("cls_links.php");
$obj_adm=new Links();
$titulo="Administrar Links Externos";
include("cls_MantixDirector1.php");
?>