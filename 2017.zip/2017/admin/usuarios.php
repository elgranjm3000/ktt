<?php
error_reporting(0);
include("cls_usuarios.php");
$obj_adm=new Usuarios();
$titulo="Administrar Usuarios";
include("cls_MantixDirector1.php");
?>