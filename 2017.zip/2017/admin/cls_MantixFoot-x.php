<div id="linkvolver">
    <a href="#inicio" style="clear:both; float:right" id="btnirup"><img src="images/b-subir-al-menu.gif"/></a>
    <div id="espaciolink">&nbsp;</div>
</div>
<div id="footblanco">&nbsp;</div>
<div align="left" id="textofoot">
    <img src="images/edfw41.gif" id="edfra" style="float:right;"/>
    ---- :: Copyright <?=date("Y")?>
</div>
<a name="#footer"></a>
<br /><br />&nbsp;
</body>
</html>