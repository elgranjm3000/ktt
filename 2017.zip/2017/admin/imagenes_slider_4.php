<?php
	error_reporting(0);
	include("cls_imagenes_slider_4.php");
	$obj_adm=new Imagenes_slider_4();
	$titulo="Administrar Im&aacute;genes de Slider";
	include("cls_MantixDirector1.php");
?>