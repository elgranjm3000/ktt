<?php
$BD = array(
			"gal_noticias"=>array("cascada"=>array(
								        array("tabla"=>"gal_notimg","campo"=>"idc")
								         )
							)
		);
?>
