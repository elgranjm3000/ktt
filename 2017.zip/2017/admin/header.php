<?php

include("cls_header.php");

$obj_adm=new Registro;

$titulo="Administrar Banner Portada";

include("cls_MantixDirector1.php");

?>